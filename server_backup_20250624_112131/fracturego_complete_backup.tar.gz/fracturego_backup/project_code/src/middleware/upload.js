const multer = require('multer');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');

// 确保上传目录存在
const uploadDir = path.join(__dirname, '../../uploads/posts');
if (!fs.existsSync(uploadDir)) {
    fs.mkdirSync(uploadDir, { recursive: true });
}

// 生成短哈希
const generateShortHash = (length = 8) => {
    return crypto.randomBytes(length).toString('hex').substring(0, length);
};

// 获取文件类型前缀
const getFileTypePrefix = (mimetype) => {
    if (mimetype.startsWith('image/')) return 'img';
    if (mimetype.startsWith('video/')) return 'vid';
    if (mimetype.startsWith('audio/')) return 'aud';
    return 'file';
};

// 配置multer存储
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, uploadDir);
    },
    filename: function (req, file, cb) {
        // 优化的文件命名方案
        // 格式: {userId}_{typePrefix}_{shortHash}_{timestamp}.{ext}
        
        const userId = req.user?.id || req.body?.userId || 'u0';
        const typePrefix = getFileTypePrefix(file.mimetype);
        const shortHash = generateShortHash(6);
        const timestamp = Date.now().toString().slice(-8); // 只取后8位
        const ext = path.extname(file.originalname).toLowerCase();
        
        // 生成新文件名：u123_img_a1b2c3_12345678.jpg
        const filename = `${userId}_${typePrefix}_${shortHash}_${timestamp}${ext}`;
        
        console.log(`�� 文件上传: ${file.originalname} -> ${filename}`);
        cb(null, filename);
    }
});

// 文件过滤器
const fileFilter = (req, file, cb) => {
    // 允许的文件类型
    const allowedTypes = {
        image: ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp'],
        video: ['video/mp4', 'video/mpeg', 'video/quicktime', 'video/webm', 'video/avi'],
        audio: ['audio/mpeg', 'audio/wav', 'audio/mp3', 'audio/ogg']
    };

    const isImageValid = allowedTypes.image.includes(file.mimetype);
    const isVideoValid = allowedTypes.video.includes(file.mimetype);
    const isAudioValid = allowedTypes.audio.includes(file.mimetype);

    if (isImageValid || isVideoValid || isAudioValid) {
        cb(null, true);
    } else {
        cb(new Error(`不支持的文件类型: ${file.mimetype}`), false);
    }
};

// 上传配置
const upload = multer({
    storage: storage,
    fileFilter: fileFilter,
    limits: {
        fileSize: 100 * 1024 * 1024, // 100MB 限制
        files: 1 // 一次只能上传一个文件
    }
});

module.exports = {
    uploadSingle: upload.single('file'), // 单文件上传
    uploadMultiple: upload.array('files', 5) // 多文件上传，最多5个
};
