// 图片请求专用速率限制（更严格）
const imageRateLimit = createRateLimit(
    60 * 1000, // 1分钟
    30, // 最多30次图片请求
    '图片请求过于频繁，请1分钟后再试'
);

// 上传文件专用速率限制
const uploadRateLimit = createRateLimit(
    5 * 60 * 1000, // 5分钟
    10, // 最多10次上传
    '文件上传过于频繁，请5分钟后再试'
);

