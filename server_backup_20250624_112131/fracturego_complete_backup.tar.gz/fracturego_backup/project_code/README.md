<div align="center">
  <a href="https://github.com/FlyDinosaur/FractureGo-Server">
    <img src="icon.svg" alt="Logo" width="80" height="80">
  </a>

  <h3 align="center">FractureGo Server</h3>

  <p align="center">
    An awesome healthcare platform backend service!
    <br />
    <a href="https://github.com/FlyDinosaur/FractureGo-Server"><strong>Explore the docs »</strong></a>
    <br />
    <br />
    <a href="https://github.com/FlyDinosaur/FractureGo-Server">View Demo</a>
    ·
    <a href="https://github.com/FlyDinosaur/FractureGo-Server/issues">Report Bug</a>
    ·
    <a href="https://github.com/FlyDinosaur/FractureGo-Server/issues">Request Feature</a>
  </p>
</div>

<!-- TABLE OF CONTENTS -->
<details>
  <summary>Table of Contents</summary>
  <ol>
    <li>
      <a href="#about-the-project">About The Project</a>
      <ul>
        <li><a href="#built-with">Built With</a></li>
      </ul>
    </li>
    <li>
      <a href="#getting-started">Getting Started</a>
      <ul>
        <li><a href="#prerequisites">Prerequisites</a></li>
        <li><a href="#installation">Installation</a></li>
      </ul>
    </li>
    <li><a href="#usage">Usage</a></li>
    <li><a href="#roadmap">Roadmap</a></li>
    <li><a href="#contributing">Contributing</a></li>
    <li><a href="#license">License</a></li>
    <li><a href="#contact">Contact</a></li>
    <li><a href="#acknowledgments">Acknowledgments</a></li>
  </ol>
</details>

<!-- ABOUT THE PROJECT -->
## About The Project

FractureGo Server is the backend service for a healthcare platform designed to assist users with bone fracture rehabilitation and care. This Node.js-based server provides robust APIs for user management, training programs, sign-in tracking, and post sharing functionality.

### Built With

* [Node.js](https://nodejs.org/)
* [Express.js](https://expressjs.com/)
* [MySQL](https://www.mysql.com/)
* [Sharp](https://sharp.pixelplumbing.com/) - For image processing
* [Multer](https://github.com/expressjs/multer) - For file uploads
* [PM2](https://pm2.keymetrics.io/) - For process management

<!-- GETTING STARTED -->
## Getting Started

This is an example of how you may give instructions on setting up your project locally.

### Prerequisites

* Node.js (v14 or higher)
* MySQL database
* npm
  ```sh
  npm install npm@latest -g
  ```

### Installation

1. Clone the repo
   ```sh
   git clone https://github.com/FlyDinosaur/FractureGo-Server.git
   ```
2. Install NPM packages
   ```sh
   npm install
   ```
3. Create your environment file
   ```sh
   cp env.example .env
   ```
4. Enter your database configuration in `.env`
   ```js
   DB_HOST=localhost
   DB_USER=your_username
   DB_PASSWORD=your_password
   DB_NAME=fracturego_db
   ```
5. Start the server
   ```sh
   npm start
   ```

<!-- USAGE EXAMPLES -->
## Usage

The server provides the following API endpoints:

- **User Management**: Registration, authentication, and profile management
- **Training Programs**: Access to rehabilitation exercises and programs
- **Sign-in Tracking**: Daily check-in functionality
- **Post Sharing**: Social features for sharing progress and experiences
- **Image Processing**: Automatic image optimization and caching

For more examples, please refer to the [Documentation](https://github.com/FlyDinosaur/FractureGo-Server)

<!-- ROADMAP -->
## Roadmap

- [x] User authentication system
- [x] Image processing and optimization
- [x] Training program management
- [x] Post sharing functionality
- [ ] Multi-language Support
    - [ ] Chinese
    - [ ] English
- [ ] Advanced analytics
- [ ] Real-time notifications

See the [open issues](https://github.com/FlyDinosaur/FractureGo-Server/issues) for a full list of proposed features (and known issues).

<!-- CONTRIBUTING -->
## Contributing

Contributions are what make the open source community such an amazing place to learn, inspire, and create. Any contributions you make are **greatly appreciated**.

If you have a suggestion that would make this better, please fork the repo and create a pull request. You can also simply open an issue with the tag "enhancement".
Don't forget to give the project a star! Thanks again!

1. Fork the Project
2. Create your Feature Branch (`git checkout -b feature/AmazingFeature`)
3. Commit your Changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the Branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

<!-- LICENSE -->
## License

Distributed under the MIT License. See `LICENSE` for more information.

<!-- CONTACT -->
## Contact

Your Name - [@your_twitter](https://twitter.com/your_username) - email@example.com

Project Link: [https://github.com/FlyDinosaur/FractureGo-Server](https://github.com/FlyDinosaur/FractureGo-Server)

<!-- ACKNOWLEDGMENTS -->
## Acknowledgments

Use this space to list resources you find helpful and would like to give credit to. I've included a few of my favorites to kick things off!

* [Choose an Open Source License](https://choosealicense.com)
* [GitHub Emoji Cheat Sheet](https://www.webpagefx.com/tools/emoji-cheat-sheet)
* [Malven's Flexbox Cheatsheet](https://flexbox.malven.co/)
* [Malven's Grid Cheatsheet](https://grid.malven.co/)
* [Img Shields](https://shields.io)
* [GitHub Pages](https://pages.github.com)
* [Font Awesome](https://fontawesome.com)
* [React Icons](https://react-icons.github.io/react-icons/search)

---

<div align="center">
  <strong>🏥 FractureGo Server 🏥</strong>
</div>
