const fs = require('fs').promises;
const path = require('path');
const mysql = require('mysql2/promise');
const crypto = require('crypto');

// 数据库配置
const dbConfig = {
    host: '117.72.161.6',
    user: 'fracturego_user',
    password: 'WYX11037414qq',
    database: 'fracturego_db'
};

// 生成短哈希
const generateShortHash = (length = 6) => {
    return crypto.randomBytes(length).toString('hex').substring(0, length);
};

// 获取文件类型前缀
const getFileTypePrefix = (filename) => {
    const ext = path.extname(filename).toLowerCase();
    if (['.jpg', '.jpeg', '.png', '.gif', '.webp'].includes(ext)) return 'img';
    if (['.mp4', '.mpeg', '.mov', '.webm', '.avi'].includes(ext)) return 'vid';
    if (['.mp3', '.wav', '.ogg'].includes(ext)) return 'aud';
    return 'file';
};

// 重命名文件的函数
const renameFile = (oldPath, userId, postId, timestamp) => {
    const ext = path.extname(oldPath);
    const typePrefix = getFileTypePrefix(oldPath);
    const shortHash = generateShortHash(6);
    const shortTimestamp = timestamp.toString().slice(-8);
    
    return `${userId}_${typePrefix}_${shortHash}_${shortTimestamp}${ext}`;
};

async function cleanupAndRename() {
    let connection;
    
    try {
        // 连接数据库
        connection = await mysql.createConnection(dbConfig);
        console.log('✅ 数据库连接成功');
        
        // 获取所有posts记录
        const [posts] = await connection.execute(
            'SELECT id, user_id, cover_image, created_at FROM posts WHERE cover_image IS NOT NULL'
        );
        
        console.log(`📂 找到 ${posts.length} 个需要处理的文件记录`);
        
        for (const post of posts) {
            const oldFilePath = post.cover_image;
            if (!oldFilePath || !oldFilePath.includes('/uploads/posts/')) continue;
            
            const filename = path.basename(oldFilePath);
            const fullOldPath = `/root/FractureGo-Server/uploads/posts/${filename}`;
            
            try {
                // 检查文件是否存在
                await fs.access(fullOldPath);
                
                // 生成新文件名
                const timestamp = new Date(post.created_at).getTime();
                const newFilename = renameFile(filename, post.user_id, post.id, timestamp);
                const newFilePath = `/root/FractureGo-Server/uploads/posts/${newFilename}`;
                
                // 重命名文件
                await fs.rename(fullOldPath, newFilePath);
                
                // 更新数据库记录
                const newDbPath = `/uploads/posts/${newFilename}`;
                await connection.execute(
                    'UPDATE posts SET cover_image = ? WHERE id = ?',
                    [newDbPath, post.id]
                );
                
                console.log(`✅ 重命名: ${filename} -> ${newFilename}`);
                
            } catch (error) {
                console.log(`❌ 处理失败 ${filename}: ${error.message}`);
            }
        }
        
        // 清理缓存目录中的旧文件
        const cacheDir = '/root/FractureGo-Server/uploads/cache';
        try {
            const cacheFiles = await fs.readdir(cacheDir);
            let cleanedCount = 0;
            
            for (const file of cacheFiles) {
                if (file.includes('_posts_4861722172488_')) {
                    await fs.unlink(path.join(cacheDir, file));
                    cleanedCount++;
                }
            }
            
            console.log(`🗑️  清理了 ${cleanedCount} 个旧缓存文件`);
        } catch (error) {
            console.log(`❌ 清理缓存失败: ${error.message}`);
        }
        
        console.log('🎉 文件清理和重命名完成！');
        
    } catch (error) {
        console.error('❌ 处理失败:', error);
    } finally {
        if (connection) {
            await connection.end();
        }
    }
}

// 运行清理脚本
cleanupAndRename();
